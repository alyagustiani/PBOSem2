public interface Teknologi {
    void gunakanTeknologi();
}
